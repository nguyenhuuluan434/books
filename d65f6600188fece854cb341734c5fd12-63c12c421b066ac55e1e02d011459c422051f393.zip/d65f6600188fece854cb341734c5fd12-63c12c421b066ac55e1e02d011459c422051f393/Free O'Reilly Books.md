Free O'Reilly books and convenient script to just download them. 

Thanks /u/FallenAege/ and /u/ShPavel/ from this [Reddit post](https://www.reddit.com/r/learnprogramming/comments/556kxj/oreilly_offering_programming_ebooks_for_free/)

How to use:

1. Take the `download.sh` file and put it into a directory where you want the files to be saved.
1. `cd` into the directory and make sure that it has executable permissions (`chmod +x download.sh` should do it)
1. Run `./download.sh` and wee there it goes. Also if you do not want all the files, just simply comment the ones you do not want.